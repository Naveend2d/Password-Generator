package logic.chars;

public interface CharGeneratable {
	public abstract char getRandom();
}
