jPasswordGenerator
==================

Java based password generator with nice and easy to use GUI written with SWING.

#Donate
Feel free to support the project if you use jPasswordGenerator =).<br/><br/>
[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=NDTRJAP2LGDRW)

#Download
You can download the jPasswordGenerator as windows binary or as a java runnable jar file. 

###Windows XP/Vista/7/8
Download the jPasswordGenerator as windows executable: [jPasswordGenerator-1.3.exe](https://dl.dropboxusercontent.com/u/3669658/github/jPasswordGenerator/jPasswordGenerator-1.3.exe "jPasswordGenerator-1.3.exe")

###Plattform independent
Download the jPasswordGenerator as a runnable jar file: [jPasswordGenerator-1.3.jar](https://dl.dropboxusercontent.com/u/3669658/github/jPasswordGenerator/jPasswordGenerator-1.3.jar "jPasswordGenerator-1.3.jar")
<br/><br/>Run the JAR via console: 
```
java -jar jPasswordGenerator-1.3.jar
```
#Screenshots
![Screenshot of the jPasswordGenerator User Interface](https://dl.dropboxusercontent.com/u/3669658/github/jPasswordGenerator/screenshot1.png "Screenshot #1")

